# $Id: README.txt,v 1.1 2006/06/08 11:49:05 dan Exp $
#

This directory contains several LaTeX .tex files which are used
by the automated regression testing to verify correct operation
of the latex-mk script.

